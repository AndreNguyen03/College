﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class SinhVien
    {
        public int stt {  get; set; }
        public string mssv { get; set; }
        public string ten {  get; set; }
        public string malop { get; set; }
        public double diemtoan { get; set; }
        public double diemanh { get; set; }
        public double diemtrungbinh { get; set; }


        public override string ToString()
        {
            return $"{stt} {mssv} {ten} {malop} {diemtoan} {diemanh} {diemtrungbinh} ";
        }
    }
}
