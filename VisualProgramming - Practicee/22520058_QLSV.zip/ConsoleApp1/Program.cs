﻿using System.Collections;

namespace ConsoleApp1
{
    internal class Program
    {
        double x = 9.0;
        public static string input;
        public static string[] inputCmd;
        static List<SinhVien> danhSachSinhVien = new List<SinhVien>();
        static void Main(string[] args)
        {
            bool tiepTuc = true;
            while (tiepTuc)
            {
                Console.WriteLine("---------------------------------");
                Console.WriteLine("print");
                Console.WriteLine("add mssv ten malop diemanh diemtoan diemtrungbinh");
                Console.WriteLine("remove mssv");
                Console.WriteLine("search ten/mssv");
                Console.WriteLine("top N true/false");
                Console.WriteLine("import destinationpath");
                Console.WriteLine("export all/malop targetpath");
                Console.WriteLine("exit");
                input = Console.ReadLine();
                inputCmd = input.Split(' ');
                string luaChon = inputCmd[0];
                switch (luaChon)
                {
                    case "print":
                        InDanhSachSinhVien();
                        break;
                    case "add":
                        ThemSinhVien();
                        break;
                    case "remove":
                        XoaSinhVien();
                        break;
                    case "search":
                        TimSinhVien();
                        break;
                    case "top":
                        XepHangSinhVien(inputCmd[1], inputCmd[2]);
                        break;
                    case "import":
                        NhapSinhVienTuFile(inputCmd[1]);
                        break;
                    case "export":
                        XuatSinhVienRaFile(inputCmd[2]);
                        break;
                    case "exit":
                        tiepTuc = false;
                        break;
                    default:
                        Console.WriteLine("Khong hop le");
                        break;
                }

            }
        }

        static void InDanhSachSinhVien()
        {
           foreach(var item in danhSachSinhVien)
            {
                Console.WriteLine(item.ToString());
            }
        }

        static void XuatSinhVienRaFile(string targetPath)
        {
            if (inputCmd[1] == "all")
            {
                List<string> lines = new List<string>();

                foreach (var sv in danhSachSinhVien)
                {
                    string line = sv.ToString();
                    lines.Add(line);
                }

                File.WriteAllText(targetPath, string.Join(Environment.NewLine, lines));

                Console.WriteLine("export successful!");
            }
            else
            {
                var danhSachTheoMaLop = danhSachSinhVien.Where(sv => sv.malop == inputCmd[1]).ToList();
                List<string> lines = new List<string>();

                foreach (var sv in danhSachTheoMaLop)
                {
                    string line = sv.ToString();
                    lines.Add(line);
                }

                File.WriteAllText(targetPath, string.Join(Environment.NewLine, lines));

                Console.WriteLine("export successful!");
            }
        }

        static void NhapSinhVienTuFile(string destinationPath)
        {
            danhSachSinhVien.Clear();
            try
            {
                using (StreamReader reader = new StreamReader(destinationPath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        line = line.Trim();
                        string[] dataParts = line.Split(' ');
                        int n = dataParts.Length ;
                        int stt = int.Parse(dataParts[0]);
                        string mssv = dataParts[1];
                        string ten = "";
                        for (int i = 2; i <= n - 5; i++)
                        {
                            ten += dataParts[i] + " ";
                        }
                        string malop = dataParts[n - 4];
                        double diemtoan = double.Parse(dataParts[n - 3]);

                        double diemanh = double.Parse(dataParts[n - 2]);

                        double diemtrungbinh = double.Parse(dataParts[n - 1]);

                        {
                            danhSachSinhVien.Add(new SinhVien
                            {
                                stt = stt,
                                mssv = mssv,
                                ten = ten,
                                malop = malop,
                                diemtoan = diemtoan,
                                diemanh = diemanh,
                                diemtrungbinh = diemtrungbinh
                            });
                        }
                    }
                }
                Console.WriteLine("import successful!");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        static void XepHangSinhVien(string n,string boolean)
        {
            int m = int.Parse(n);
            if (boolean == "true")
            {
                var sinhVienSapXep = danhSachSinhVien
            .OrderByDescending(sv => sv.diemtrungbinh)
            .ThenBy(sv => sv.mssv)
            .ToList();

                // Lấy điểm trung bình cao thứ n
                double diemTrungBinhCaoThuN = sinhVienSapXep
                    .Select(sv => sv.diemtrungbinh)
                    .Distinct()
                    .OrderByDescending(diem => diem)
                    .Skip(m - 1)
                    .FirstOrDefault();

                // Lọc danh sách để chỉ lấy các sinh viên có điểm trung bình lớn hơn hoặc bằng điểm trung bình cao thứ n
                var sinhVienDiemCaoThuN = sinhVienSapXep
                    .Where(sv => sv.diemtrungbinh >= diemTrungBinhCaoThuN)
                    .ToList();
                Console.WriteLine($"Danh sach sinh vien top  {m} gioi nhat: ");
                foreach(var item in sinhVienDiemCaoThuN.ToList())
                {
                    Console.WriteLine(item.ToString());
                }
            }
            else if( boolean =="false")
            {
                var sinhVienSapXep = danhSachSinhVien
            .OrderByDescending(sv => sv.diemtrungbinh)
            .ThenBy(sv => sv.mssv)
            .ToList();

                // Lấy điểm trung bình cao thứ n
                double diemTrungBinhCaoThuN = sinhVienSapXep
                    .Select(sv => sv.diemtrungbinh)
                    .Distinct()
                    .OrderBy(diem => diem)
                    .Skip(m - 1)
                    .FirstOrDefault();

                // Lọc danh sách để chỉ lấy các sinh viên có điểm trung bình lớn hơn hoặc bằng điểm trung bình cao thứ n
                var sinhVienDiemCaoThuN = sinhVienSapXep
                    .Where(sv => sv.diemtrungbinh <= diemTrungBinhCaoThuN)
                    .ToList();
                Console.WriteLine($"Danh sach sinh vien top {m} te nhat: ");
                foreach (var item in sinhVienDiemCaoThuN.ToList())
                {
                    Console.WriteLine(item.ToString());
                }
            }
        }

        static void ThemSinhVien()
        {
            
            string mssv = inputCmd[1];
            string ten = "";
            for (int i = 2; i <= inputCmd.Length - 5; i++)
            {
                ten += inputCmd[i] + " ";
            }
            string maLop = inputCmd[inputCmd.Length - 4];
            double diemToan = double.Parse(inputCmd[inputCmd.Length - 3]);
            double diemAnh = double.Parse(inputCmd[inputCmd.Length - 2]);
            double diemTrungBinh = double.Parse(inputCmd[inputCmd.Length - 1]);
            
            danhSachSinhVien.Add(new SinhVien {
                                    stt = danhSachSinhVien.Count+1,
                                    mssv = mssv,
                                    ten = ten,
                                    malop = maLop,
                                    diemtoan = diemToan,
                                    diemanh = diemAnh,
                                    diemtrungbinh = diemTrungBinh });
        }

        static void XoaSinhVien()
        {
            string mssv = inputCmd[1];
            var sinhVienCanXoa = danhSachSinhVien.FirstOrDefault(sv => sv.mssv == mssv);
            if (sinhVienCanXoa != null)
            {
                danhSachSinhVien.Remove(sinhVienCanXoa);
                Console.WriteLine("Removed");
            }
            else
            {
                Console.WriteLine("Can not find this Sinh Vien");
            }
        }

        static void TimSinhVien()
        {
            
            string timKiem = inputCmd[1];
            var ketQua = danhSachSinhVien.Where(sv => sv.mssv.Contains(timKiem) || sv.ten.Contains(timKiem)).ToList();
            if (ketQua.Any())
            {
                Console.WriteLine("Search result:");
                foreach (var sv in ketQua)
                {
                    Console.WriteLine(sv);
                }
            }
            else
            {
                Console.WriteLine("Can not search this Sinh Vien.");
            }
        }
    }
}