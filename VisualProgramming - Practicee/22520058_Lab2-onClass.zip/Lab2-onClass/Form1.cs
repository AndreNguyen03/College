﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Button = System.Windows.Forms.Button;

namespace Lab2_onClass
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            label.Text = "Form da activate";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Form da duoc load");
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            MessageBox.Show("Form da duoc dong");
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(MessageBox.Show("Ban co chac chan muon dong form?  ","Xac nhan", MessageBoxButtons.YesNo)!= DialogResult.Yes)
            {
                e.Cancel = true;
            }

        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            MessageBox.Show("Form da duoc shown");
        }

        private void Form1_Deactivate(object sender, EventArgs e)
        {
            label.Text = "Form da bi deactivate";
        }
    }
}
