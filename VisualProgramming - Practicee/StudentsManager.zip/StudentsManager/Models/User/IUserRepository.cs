﻿using StudentsManager.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentsManager.Models.User
{
    public interface IUserRepository
    {
        bool GetByUserAndPassword(string name, string password);
    }
}
