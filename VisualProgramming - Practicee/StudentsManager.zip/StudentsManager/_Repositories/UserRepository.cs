﻿using StudentsManager.Model;
using StudentsManager.Models.User;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentsManager._Repositories
{
    public class UserRepository : IUserRepository
    {
        private const string fileName = "User.txt";
        string fullPath = Path.GetFullPath(fileName).ToString();
        public bool GetByUserAndPassword(string name, string password)
        {
            var userList = new List<UserModel>();
            string _username = name;
            string _password = password;
            bool isLogin;
            fullPath = fullPath.Remove(fullPath.Length - 18, 18);
            fullPath += "Data\\User.txt";
            using (var streamReader = new StreamReader(fullPath))
            {
                string line = string.Empty;
                while ((line = streamReader.ReadLine()) != null)
                {
                    line = line.Trim();
                    string[] dataParts = line.Split(' ');
                    string readUsername = dataParts[0];
                    string readPassword = dataParts[1];
                    if (_username.Equals(readUsername) && _password.Equals(readPassword))
                    {
                        userList.Add(new UserModel
                        {
                            username = readUsername,
                            password = readPassword
                        }); 
                    }
                }
            }
            if (userList.Count > 0)
            {
                isLogin = true;
            }
            else isLogin = false;
            return isLogin;
        }

    }
}
