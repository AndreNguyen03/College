﻿using StudentsManager.Model;
using StudentsManager.Models.Student;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentsManager._Repositories
{
    public class StudentRepository :  IStudentRepository

    {
        private const string fileName = "Data.txt";
        public void Add(StudentModel studentModel)
        {
            FileInfo file = new FileInfo(fileName);
            string fullPath = file.FullName;
            fullPath = fullPath.Remove(fullPath.Length - 18, 18);
            fullPath += "Data\\Data.txt";
            StreamWriter streamWriter;
            if (!File.Exists(fullPath))
            {
                streamWriter = new StreamWriter(fullPath);
            }
            else
            {
                streamWriter = File.AppendText(fullPath);
            }
            streamWriter.WriteLine(studentModel.ToString());
            streamWriter.Flush();
            streamWriter.Close();
        }

        public IEnumerable<StudentModel> GetAll()
        {
            var studentList = new List<StudentModel>();
            FileInfo file = new FileInfo(fileName);
            string fullPath = file.FullName;
            fullPath = fullPath.Remove(fullPath.Length - 18, 18);
            fullPath += "Data\\Data.txt";
            using (var streamReader = new StreamReader(fullPath))
            {
                string line = string.Empty;
                while ((line = streamReader.ReadLine()) != null)
                {
                    line = line.Trim();
                    string[] dataParts = line.Split(' ');
                    int n = dataParts.Length;
                    string id = dataParts[0];
                    string name = "";
                    for (int i = 1; i <= n - 5; i++)
                    {
                        name += dataParts[i] + " ";
                    }
                    string className = dataParts[n - 4];
                    float mathScore = float.Parse(dataParts[n - 3]);

                    float literatureScore = float.Parse(dataParts[n - 2]);

                    float englishScore = float.Parse(dataParts[n - 1]);
                    {
                        studentList.Add(new StudentModel
                        {
                            Id = id,
                            Name = name.Trim(),
                            ClassName = className,
                            MathScore = mathScore,
                            LiteratureScore = literatureScore,
                            EnglishScore = englishScore
                        });
                    }
                }
            }
            return studentList;
        }

        public IEnumerable<StudentModel> GetByValue(string value)
        {
            var studentList = new List<StudentModel>();
            string studentId = value;
            string studentName = value;
            FileInfo file = new FileInfo(fileName);
            string fullPath = file.FullName;
            fullPath = fullPath.Remove(fullPath.Length - 18, 18);
            fullPath += "Data\\Data.txt";
            string[] textLines = File.ReadAllLines(fullPath);

            foreach (string line in textLines)
            {
                if (line.Contains(studentId) || line.Contains(studentName))
                {
                    string[] dataParts = line.Split(' ');
                    int n = dataParts.Length;
                    string id = dataParts[0];
                    string name = "";
                    for (int i = 1; i <= n - 5; i++)
                    {
                        name += dataParts[i] + " ";
                    }
                    string className = dataParts[n - 4];
                    float mathScore = float.Parse(dataParts[n - 3]);

                    float literatureScore = float.Parse(dataParts[n - 2]);

                    float englishScore = float.Parse(dataParts[n - 1]);
                    {
                        studentList.Add(new StudentModel
                        {
                            Id = id,
                            Name = name.Trim(),
                            ClassName = className,
                            MathScore = mathScore,
                            LiteratureScore = literatureScore,
                            EnglishScore = englishScore
                        });
                    }
                }
            }

            return studentList;
        }

    }
}
