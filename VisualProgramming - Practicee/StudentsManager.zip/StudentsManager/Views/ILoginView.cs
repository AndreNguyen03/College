﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentsManager.Views
{
    public interface ILoginView
    {
        string UserName { get; set; }
        string Password { get; set; }


        event EventHandler Login;

        void ClearFields();
        void Hide();
        void Show();
    }
}
