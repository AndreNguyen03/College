﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentsManager.Views
{
    public partial class StudentView : Form,IStudentView
    {
        //Fields
        
        private string messageSV;
        private bool isSuccessfulSV;
        private bool isEditSV;
        private ILoginView loginView;
        public StudentView(ILoginView loginView=null)
        {
            this.loginView = loginView;
            InitializeComponent();
            AssociateAndRaiseViewEvents();
        }

        

        private void AssociateAndRaiseViewEvents()
        {
            tabControlStudent.TabPages.Remove(tabPageStudentDetail);

            //Mainview Closed => show loginview
            //Search
            btnSearch.Click += delegate { SearchEvent?.Invoke(this, EventArgs.Empty); };
            textBoxSearchStudent.KeyDown += (s, e) => {
                if(e.KeyCode == Keys.Enter)
                {
                    SearchEvent?.Invoke(this, EventArgs.Empty);
                }
            };
            //Add new
            btnAddNew.Click += delegate 
            { 
                AddNewEvent?.Invoke(this, EventArgs.Empty);
                tabControlStudent.TabPages.Add(tabPageStudentDetail);
                tabControlStudent.TabPages.Remove(tabPageStudentList);
                tabPageStudentDetail.Text = "Add new student";
            };
            
            //Save
            btnSave.Click += delegate 
            { 
                SaveEvent?.Invoke(this, EventArgs.Empty); 
                if(isSuccessful)
                {
                    tabControlStudent.TabPages.Remove(tabPageStudentDetail);
                    tabControlStudent.TabPages.Add(tabPageStudentList);
                }
                MessageBox.Show(message);
            };
            //Cancel
            btnCancel.Click += delegate
            { 
                CancelEvent?.Invoke(this, EventArgs.Empty);
                tabControlStudent.TabPages.Remove(tabPageStudentDetail); 
                tabControlStudent.TabPages.Add(tabPageStudentList);
            };

        }

        public string studentId { get => textBoxStudentId.Text; set => textBoxStudentId.Text = value; }
        public string studentName { get => textBoxStudentName.Text; set => textBoxStudentName.Text = value; }
        public string studentClassName { get => comboBoxClassName.Text; set => comboBoxClassName.Text = value; }
        public float mathScore { get => float.Parse(textBoxMathScore.Text); set => textBoxMathScore.Text = value.ToString(); }
        public float literatureScore { get => float.Parse(textBoxLiteratureScore.Text); set => textBoxLiteratureScore.Text = value.ToString(); }
        public float englishScore { get => float.Parse(textBoxEnglishScore.Text); set => textBoxEnglishScore.Text = value.ToString(); }
        public string searchValue { get => textBoxSearchStudent.Text; set => textBoxSearchStudent.Text = value; }
        public bool isEdit { get => isEditSV; set => isEditSV = value; }
        public bool isSuccessful { get => isSuccessfulSV; set => isSuccessfulSV = value; }
        public string message { get => messageSV; set => messageSV = value; }

        public event EventHandler SearchEvent;
        public event EventHandler AddNewEvent;
        public event EventHandler SaveEvent;
        public event EventHandler CancelEvent;

        public void SetStudentListBindingSource(BindingSource studentList)
        {
            dataGridViewStudentList.DataSource = studentList;
        }

        //Singleton pattern (Open a single form instance)
        private static StudentView instance;
        public static StudentView GetInstance(ILoginView view)
        {
            if(instance ==null || instance.IsDisposed)
            {
                instance = new StudentView(view);
            } else
            {
                if(instance.WindowState == FormWindowState.Minimized)
                {
                    instance.WindowState = FormWindowState.Normal;
                }
                instance.BringToFront();
            }
            return instance;
        }

        private void StudentView_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.loginView.Show();
            this.loginView.ClearFields();
        }

    }
}
