﻿using System.Diagnostics;
using System.Security.Policy;

namespace calculateArray
{
    public partial class Form1 : Form
    {
        private string filePath = "file.txt";
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GenerateNumber(filePath, 1000000);
            try
            {
                string text = File.ReadAllText(filePath);
                rtbNumber.Text = text;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GenerateNumber(string filePath, int count)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                Random random = new Random();

                for (int i = 0; i < count; i++)
                {
                    int randomNumber = random.Next(0, 1000000);
                    writer.WriteLine(randomNumber);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            string[] lines = File.ReadAllLines(filePath);
            int[] array = lines.Select(line => int.Parse(line)).ToArray();
            // Split the array into chunks
            int chunkSize = array.Length / Environment.ProcessorCount;
            List<Thread> threads = new List<Thread>();
            int[] partialSums = new int[Environment.ProcessorCount];

            for (int i = 0; i < Environment.ProcessorCount; i++)
            {
                int start = i * chunkSize;
                int end = (i == Environment.ProcessorCount - 1) ? array.Length : (i + 1) * chunkSize;

                threads.Add(new Thread((index) =>
                {
                    int threadIndex = (int)index;
                    for (int j = start; j < end; j++)
                    {
                        partialSums[threadIndex] += array[j];
                    }
                }));
            }

            // Start all threads
            foreach (Thread thread in threads)
            {
                thread.Start(threads.IndexOf(thread));
            }

            // Wait for all threads to finish
            foreach (Thread thread in threads)
            {
                thread.Join();
            }

            // Calculate the final sum
            int finalSum = partialSums.Sum();

            stopwatch.Stop();
            lbTotalNumber.Text = $"Total : {finalSum}";
            lbTotalTime.Text = $"Total time : {stopwatch.ElapsedMilliseconds} milisecs";
        }



    }
}
