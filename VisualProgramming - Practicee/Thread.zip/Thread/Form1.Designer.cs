﻿namespace calculateArray
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnGenerate = new Button();
            btnCalculate = new Button();
            rtbNumber = new RichTextBox();
            lbTotalNumber = new Label();
            lbTotalTime = new Label();
            SuspendLayout();
            // 
            // btnGenerate
            // 
            btnGenerate.BackColor = Color.FromArgb(67, 197, 70);
            btnGenerate.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnGenerate.Location = new Point(106, 284);
            btnGenerate.Margin = new Padding(2);
            btnGenerate.Name = "btnGenerate";
            btnGenerate.Size = new Size(103, 37);
            btnGenerate.TabIndex = 0;
            btnGenerate.Text = "Generate";
            btnGenerate.UseVisualStyleBackColor = false;
            btnGenerate.Click += button1_Click;
            // 
            // btnCalculate
            // 
            btnCalculate.BackColor = Color.FromArgb(216, 157, 37);
            btnCalculate.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnCalculate.Location = new Point(280, 282);
            btnCalculate.Margin = new Padding(2);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(108, 41);
            btnCalculate.TabIndex = 1;
            btnCalculate.Text = "Calculate";
            btnCalculate.UseVisualStyleBackColor = false;
            btnCalculate.Click += button2_Click;
            // 
            // rtbNumber
            // 
            rtbNumber.BackColor = Color.FromArgb(148, 250, 244);
            rtbNumber.BorderStyle = BorderStyle.None;
            rtbNumber.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            rtbNumber.ForeColor = Color.Black;
            rtbNumber.Location = new Point(37, 12);
            rtbNumber.Name = "rtbNumber";
            rtbNumber.ReadOnly = true;
            rtbNumber.Size = new Size(426, 184);
            rtbNumber.TabIndex = 2;
            rtbNumber.Text = "";
            // 
            // lbTotalNumber
            // 
            lbTotalNumber.AutoSize = true;
            lbTotalNumber.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lbTotalNumber.Location = new Point(178, 208);
            lbTotalNumber.Name = "lbTotalNumber";
            lbTotalNumber.Size = new Size(0, 21);
            lbTotalNumber.TabIndex = 3;
            // 
            // lbTotalTime
            // 
            lbTotalTime.AutoSize = true;
            lbTotalTime.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lbTotalTime.Location = new Point(163, 245);
            lbTotalTime.Name = "lbTotalTime";
            lbTotalTime.Size = new Size(0, 21);
            lbTotalTime.TabIndex = 4;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(498, 345);
            Controls.Add(lbTotalTime);
            Controls.Add(lbTotalNumber);
            Controls.Add(rtbNumber);
            Controls.Add(btnCalculate);
            Controls.Add(btnGenerate);
            DoubleBuffered = true;
            Margin = new Padding(2);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnGenerate;
        private Button btnCalculate;
        private RichTextBox rtbNumber;
        private Label lbTotalNumber;
        private Label lbTotalTime;
    }
}